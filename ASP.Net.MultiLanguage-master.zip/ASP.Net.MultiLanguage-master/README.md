ASP.Net.MultiLanguage
=====================
Author: chienvh
Author URI: https://facebook.com/chienvh
Skype: chien.vh
Description: This source code contains the code for multi language app, coded by visual studio 2012, ASP.Net C#
Version: 1.0
License: by ChienVH
